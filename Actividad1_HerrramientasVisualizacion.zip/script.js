/**
 * Dashboard de Tendencias en Reservas Hoteleras - Script principal
 *
 * Análisis tendencias en D3.js
 * Presentado por:  Cristian Arauz Castillo
 * 				    Rommel Correa Terán
 * 				    Ramiro Merchán Mora
 * 				    Dylan Tumaille Quintana
 * Asignatura: 	    Herramiuentas de Visualización
 * Docente: 	    Dr. Mario Modesto Mata
 */

// ==========================================================================
// 1. VARIABLES GLOBALES Y CONFIGURACIÓN
// ==========================================================================

/**
 * Almacena todos los datos cargados desde el CSV para su uso en las visualizaciones
 */
let fullData = [];

/**
 * Define el orden de los meses para visualizaciones temporales
 */
const monthOrder = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

/**
 * Define los esquemas de colores para las diferentes categorías en las visualizaciones
 */
const colors = {
    // Colores para tipos de hotel
    hotels: {
        "Resort Hotel": "#9467bd",  // Morado
        "City Hotel": "#17becf"     // Cian
    },
    // Colores para tipos de cliente
    customerTypes: {
        "Transient": "#1f77b4",     // Azul
        "Transient-Party": "#d62728", // Rojo
        "Contract": "#ff7f0e",      // Naranja
        "Group": "#2ca02c"         // Verde
    },
    // Colores para canales de distribución
    channels: {
        "Direct": "#E67E22",
        "TA/TO": "#9B59B6", 
        "Corporate": "#2980B9",
        "GDS": "#27AE60"
    },
    // Colores para segmentos de mercado
    segments: {
        "Direct": "#E67E22",
        "Online TA": "#8E44AD",
        "Offline TA/TO": "#9B59B6",
        "Groups": "#2980B9",
        "Corporate": "#27AE60",
        "Aviation": "#16A085",
        "Complementary": "#D35400"
    },
    // Colores para estado de reserva
    status: {
        "canceled": "#E74C3C",
        "not_canceled": "#2ECC71"
    }
};

// ==========================================================================
// 2. FUNCIONES DE UTILIDAD Y FORMATEO
// ==========================================================================

/**
 * Formatea números con separadores de miles según la localización española
 * @param {number} num - Número a formatear
 * @returns {string} - Número formateado
 */
const formatNumber = (num) => {
    return new Intl.NumberFormat('es-ES').format(num);
};

/**
 * Formatea números como porcentajes según la localización española
 * @param {number} num - Número a formatear (0-1)
 * @returns {string} - Porcentaje formateado
 */
const formatPercent = (num) => {
    return new Intl.NumberFormat('es-ES', { 
        style: 'percent',
        maximumFractionDigits: 1
    }).format(num);
};

/**
 * Ajusta texto largo dividiéndolo en múltiples líneas
 * @param {d3.Selection} text - Selección de texto de D3 a ajustar
 * @param {number} width - Ancho máximo de línea
 */
function wrapText(text, width) {
    text.each(function() {
        const t = d3.select(this);
        const words = t.text().split(/\s+/).reverse();
        let word;
        let line = [];
        let lineNumber = 0;
        const lineHeight = 1.1;
        const y = t.attr("y");
        const dy = parseFloat(t.attr("dy"));
        let tspan = t.text(null).append("tspan").attr("x", t.attr("x")).attr("y", y).attr("dy", dy + "em");
        
        while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(" "));
            if (tspan.node() && tspan.node().getComputedTextLength() > width) {
                line.pop();
                tspan.text(line.join(" "));
                line = [word];
                tspan = t.append("tspan").attr("x", t.attr("x")).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
            }
        }
    });
}

/**
 * Calcula la correlación entre dos conjuntos de datos
 * @param {Array<number>} x - Primer conjunto de datos
 * @param {Array<number>} y - Segundo conjunto de datos
 * @returns {number} - Coeficiente de correlación (-1 a 1)
 */
function calculateCorrelation(x, y) {
    if (!x || !y || x.length !== y.length || x.length === 0) {
        return 0;
    }
    
    try {
        const n = x.length;
        const sum_x = x.reduce((a, b) => a + b, 0);
        const sum_y = y.reduce((a, b) => a + b, 0);
        const sum_xy = x.reduce((total, xi, i) => total + (xi * y[i]), 0);
        const sum_x2 = x.reduce((total, xi) => total + (xi * xi), 0);
        const sum_y2 = y.reduce((total, yi) => total + (yi * yi), 0);
        
        const numerator = (n * sum_xy) - (sum_x * sum_y);
        const denominator = Math.sqrt(((n * sum_x2) - (sum_x * sum_x)) * ((n * sum_y2) - (sum_y * sum_y)));
        
        if (denominator === 0) return 0;
        return numerator / denominator;
    } catch (error) {
        console.error("Error al calcular correlación:", error);
        return 0;
    }
}

/**
 * Crea y retorna un elemento tooltip si no existe
 * @returns {d3.Selection} - Elemento tooltip
 */
function getTooltip() {
    try {
        let tooltip = d3.select("body").select(".tooltip");
        
        if (tooltip.empty()) {
            tooltip = d3.select("body").append("div")
                .attr("class", "tooltip")
                .style("opacity", 0);
        }
        
        return tooltip;
    } catch (error) {
        console.error("Error al crear tooltip:", error);
        // Crear un tooltip de respaldo en caso de error
        return d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);
    }
}

// ==========================================================================
// 3. CARGA Y PROCESAMIENTO DE DATOS
// ==========================================================================

/**
 * Carga y procesa los datos desde el archivo CSV
 */
async function loadData() {
    try {
        // Cargar el archivo CSV
        const response = await fetch('hotel_bookings.csv');
        const csvData = await response.text();
        
        // Parsear CSV
        Papa.parse(csvData, {
            header: true,         
            delimiter: ";",       
            dynamicTyping: true,  
            skipEmptyLines: true, 
            complete: function(results) {
                // Guardar los datos parseados
                fullData = results.data;
                
                // Limpiar y transformar datos
                processData();
                
                // Inicializar el dashboard
                initializeDashboard();
            },
            error: function(error) {
                console.error("Error al parsear CSV:", error);
                showError("Error al procesar los datos: " + error.message);
            }
        });
    } catch (error) {
        console.error("Error al cargar los datos:", error);
        showError("Error al cargar los datos: " + error.message);
    }
}

/**
 * Procesa los datos cargados para prepararlos para visualización
 */
function processData() {
    // Transformar y limpiar datos
    fullData.forEach(d => {
        try {
            // Asegurarse de que los valores numéricos sean números
            d.adr = +d.adr || 0;
            d.lead_time = +d.lead_time || 0;
            d.is_canceled = +d.is_canceled || 0;
            d.stays_in_weekend_nights = +d.stays_in_weekend_nights || 0;
            d.stays_in_week_nights = +d.stays_in_week_nights || 0;
            d.adults = +d.adults || 0;
            d.children = +(d.children || 0);
            d.babies = +(d.babies || 0);
            d.total_of_special_requests = +d.total_of_special_requests || 0;
            
            // Calcular noches totales para análisis de duración
            d.total_nights = d.stays_in_weekend_nights + d.stays_in_week_nights;
            
            // Categorizar duración de estancia
            if (d.total_nights <= 2) d.stay_category = "1-2 noches";
            else if (d.total_nights <= 5) d.stay_category = "3-5 noches";
            else if (d.total_nights <= 10) d.stay_category = "6-10 noches";
            else d.stay_category = "Más de 10 noches";
        } catch (error) {
            console.warn("Error al procesar fila de datos:", error);
        }
    });
    
    // Mostrar en consola información sobre los datos cargados
    console.log(`Datos cargados: ${fullData.length} registros`);
}

/**
 * Muestra un mensaje de error en los contenedores de gráficos
 * @param {string} message - Mensaje de error a mostrar
 */
function showError(message) {
    document.querySelectorAll('.chart').forEach(chart => {
        chart.innerHTML = `<p class="error-message">Error: ${message}</p>`;
    });
}

/**
 * Inicializa el dashboard después de cargar los datos
 */
function initializeDashboard() {
    // Actualizar selectores de año
    populateYearFilters();
    
    // Mostrar indicadores globales
    updateIndicators(fullData);
    
    // Inicializar gráficos
    createSankeyChart(fullData);
    createPriceHeatmap(fullData);
    createBubbleChart(fullData);
    
    // Configurar filtros e interactividad
    setupFilters();
    
    // Actualizar fecha del dataset en el footer
    const dateElement = document.getElementById('data-date');
    if (dateElement) {
        dateElement.textContent = new Date().getFullYear();
    }
}

/**
 * Actualiza los indicadores globales en el dashboard
 * @param {Array} data - Datos a utilizar para calcular indicadores
 */
function updateIndicators(data) {
    try {
        // Total reservas
        const totalElement = document.getElementById('total-reservas');
        if (totalElement) {
            totalElement.textContent = formatNumber(data.length);
        }
        
        // Tasa cancelación
        const canceledCount = data.filter(d => d.is_canceled === 1).length;
        const cancelationRate = canceledCount / data.length;
        const cancelElement = document.getElementById('tasa-cancelacion');
        if (cancelElement) {
            cancelElement.textContent = formatPercent(cancelationRate);
        }
        
        // ADR promedio (precio medio por noche)
        const avgAdr = data.reduce((sum, d) => sum + (d.adr || 0), 0) / data.length;
        const adrElement = document.getElementById('adr-promedio');
        if (adrElement) {
            adrElement.textContent = formatNumber(Math.round(avgAdr));
        }
        
        // Estancia promedio
        const avgStay = data.reduce((sum, d) => sum + (d.total_nights || 0), 0) / data.length;
        const stayElement = document.getElementById('estancia-promedio');
        if (stayElement) {
            stayElement.textContent = formatNumber(avgStay.toFixed(1));
        }
    } catch (error) {
        console.error("Error al actualizar indicadores:", error);
    }
}

/**
 * Llena los filtros de año con los valores disponibles en el dataset
 */
function populateYearFilters() {
    try {
        // Obtener años únicos del dataset
        const years = [...new Set(fullData.map(d => d.arrival_date_year))].sort();
        
        // Identificar selectores que deben ser poblados
        const yearSelects = [
            document.getElementById('year-filter-1'),
            document.getElementById('year-filter-2')
        ];
        
        // Agregar opciones a cada selector
        yearSelects.forEach(select => {
            if (!select) return;
            
            // Limpiar opciones existentes (excepto 'todos')
            const defaultOption = select.querySelector('option[value="todos"]');
            select.innerHTML = '';
            if (defaultOption) {
                select.appendChild(defaultOption);
            }
            
            // Añadir opciones de año
            years.forEach(year => {
                if (year) {
                    const option = document.createElement('option');
                    option.value = year;
                    option.textContent = year;
                    select.appendChild(option);
                }
            });
        });
    } catch (error) {
        console.error("Error al popular filtros de año:", error);
    }
}

// ==========================================================================
// 4. GRÁFICO 1: DIAGRAMA SANKEY (CANALES, SEGMENTOS Y CANCELACIONES)
// ==========================================================================

/**
 * Crea el diagrama Sankey para visualizar el flujo de reservas
 * @param {Array} data - Datos a visualizar
 */
function createSankeyChart(data) {
    try {
        // Limpiar el contenedor
        const chartContainer = d3.select("#chart1").html("");
        
        // Crear SVG
        const svg = chartContainer.append("svg")
            .attr("width", "100%")
            .attr("height", "100%")
            .attr("viewBox", `0 0 900 500`)
            .attr("preserveAspectRatio", "xMidYMid meet");
                
        // Configurar margen superior
        const margin = {top: 50, right: 30, bottom: 20, left: 30};
        const width = 900 - margin.left - margin.right;
        const height = 500 - margin.top - margin.bottom;
        const g = svg.append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);
                
        // Preparar datos para Sankey
        const channelNodes = [...new Set(data.map(d => d.distribution_channel))].filter(Boolean);
        const segmentNodes = [...new Set(data.map(d => d.market_segment))].filter(Boolean);
        const statusNodes = ["Canceled", "Not Canceled"];
        
        // Crear nodos para Sankey
        const nodes = [
            ...channelNodes.map(name => ({ name, type: 'channel' })),
            ...segmentNodes.map(name => ({ name, type: 'segment' })),
            ...statusNodes.map(name => ({ name, type: 'status' }))
        ];
        
        // Crear links para Sankey
        const links = [];
        
        // Channel -> Segment
        channelNodes.forEach(channel => {
            segmentNodes.forEach(segment => {
                const value = data.filter(d => d.distribution_channel === channel && d.market_segment === segment).length;
                if (value > 0) {
                    links.push({
                        source: nodes.findIndex(n => n.name === channel && n.type === 'channel'),
                        target: nodes.findIndex(n => n.name === segment && n.type === 'segment'),
                        value
                    });
                }
            });
        });
        
        // Segment -> Status
        segmentNodes.forEach(segment => {
            const canceled = data.filter(d => d.market_segment === segment && d.is_canceled === 1).length;
            const notCanceled = data.filter(d => d.market_segment === segment && d.is_canceled === 0).length;
            
            if (canceled > 0) {
                links.push({
                    source: nodes.findIndex(n => n.name === segment && n.type === 'segment'),
                    target: nodes.findIndex(n => n.name === "Canceled" && n.type === 'status'),
                    value: canceled
                });
            }
            
            if (notCanceled > 0) {
                links.push({
                    source: nodes.findIndex(n => n.name === segment && n.type === 'segment'),
                    target: nodes.findIndex(n => n.name === "Not Canceled" && n.type === 'status'),
                    value: notCanceled
                });
            }
        });
        
        // Implementar diagrama Sankey usando la librería d3-sankey
        const sankey = d3.sankey()
            .nodeWidth(15)
            .nodePadding(10)
            .extent([[0, 0], [width, height]]);
                
        const { nodes: sankeyNodes, links: sankeyLinks } = sankey({
            nodes: nodes.map(d => Object.assign({}, d)),
            links: links.map(d => Object.assign({}, d))
        });
        
        // Obtener tooltip
        const tooltip = getTooltip();
        
        // Dibujar enlaces
        const link = g.append("g")
            .selectAll("path")
            .data(sankeyLinks)
            .join("path")
            .attr("class", "link")
            .attr("d", d3.sankeyLinkHorizontal())
            .attr("stroke", d => {
                if (d.target.name === "Canceled") return colors.status.canceled;
                if (d.target.name === "Not Canceled") return colors.status.not_canceled;
                
                const sourceType = d.source.type;
                const sourceName = d.source.name;
                
                if (sourceType === 'channel') {
                    return colors.channels[sourceName] || "#999";
                } else if (sourceType === 'segment') {
                    return colors.segments[sourceName] || "#999";
                }
                
                return "#999";
            })
            .attr("stroke-width", d => Math.max(1, d.width))
            .on("mouseover", function(event, d) {
                d3.select(this)
                    .attr("stroke-opacity", 0.8)
                    .attr("stroke-width", d => Math.max(1, d.width + 2));
                    
                tooltip.transition()
                    .duration(200)
                    .style("opacity", .9);
                    
                let sourceText = d.source.name;
                let targetText = d.target.name;
                let value = d.value;
                let percentage = (value / data.length * 100).toFixed(1) + "%";
                
                tooltip.html(`<strong>${sourceText} → ${targetText}</strong><br>
                             Reservas: ${value} (${percentage})`)
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 28) + "px");
            })
            .on("mouseout", function() {
                d3.select(this)
                    .attr("stroke-opacity", 0.5)
                    .attr("stroke-width", d => Math.max(1, d.width));
                    
                tooltip.transition()
                    .duration(500)
                    .style("opacity", 0);
            });
        
        // Dibujar nodos
        const node = g.append("g")
            .selectAll("rect")
            .data(sankeyNodes)
            .join("rect")
            .attr("class", "node")
            .attr("x", d => d.x0)
            .attr("y", d => d.y0)
            .attr("height", d => d.y1 - d.y0)
            .attr("width", d => d.x1 - d.x0)
            .attr("fill", d => {
                if (d.type === 'channel') return colors.channels[d.name] || "#999";
                if (d.type === 'segment') return colors.segments[d.name] || "#999";
                if (d.name === "Canceled") return colors.status.canceled;
                if (d.name === "Not Canceled") return colors.status.not_canceled;
                return "#999";
            })
            .attr("stroke", "#000")
            .on("mouseover", function(event, d) {
                d3.select(this).attr("stroke-width", 2);
                
                // Resaltar enlaces conectados
                link.filter(l => l.source === d || l.target === d)
                    .attr("stroke-opacity", 0.8)
                    .attr("stroke-width", l => Math.max(1, l.width + 2));
                
                tooltip.transition()
                    .duration(200)
                    .style("opacity", .9);
                
                const total = d.value;
                const percentage = (total / data.length * 100).toFixed(1) + "%";
                
                tooltip.html(`<strong>${d.name}</strong><br>
                             Reservas: ${total} (${percentage})`)
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 28) + "px");
            })
            .on("mouseout", function() {
                d3.select(this).attr("stroke-width", 1);
                
                link.attr("stroke-opacity", 0.5)
                    .attr("stroke-width", l => Math.max(1, l.width));
                
                tooltip.transition()
                    .duration(500)
                    .style("opacity", 0);
            });
        
        // Añadir etiquetas
        g.append("g")
            .selectAll("text")
            .data(sankeyNodes)
            .join("text")
            .attr("x", d => d.x0 < width / 2 ? d.x1 + 6 : d.x0 - 6)
            .attr("y", d => (d.y1 + d.y0) / 2)
            .attr("dy", "0.35em")
            .attr("text-anchor", d => d.x0 < width / 2 ? "start" : "end")
            .text(d => d.name)
            .style("font-size", "12px")
            .style("font-weight", d => d.type === "status" ? "bold" : "normal")
            .call(wrapText, 100);
            
        // Añadir títulos de columnas con mejor alineación
        const columnTitles = [
            { x: 0, text: "Canales de Distribución", align: "start" },
            { x: width / 2, text: "Segmentos de Mercado", align: "middle" },
            { x: width, text: "Estado Final", align: "end" }
        ];
        
        // Posicionar títulos de columna por encima de los nodos
        g.selectAll(".column-title")
            .data(columnTitles)
            .join("text")
            .attr("class", "column-title")
            .attr("x", d => d.x)
            .attr("y", -30)
            .attr("text-anchor", d => d.align)
            .attr("font-size", "14px")
            .attr("font-weight", "bold")
            .attr("fill", "#555")
            .text(d => d.text);
    } catch (error) {
        console.error("Error al crear diagrama Sankey:", error);
        d3.select("#chart1").html("<p class='error-message'>Error al crear la visualización: " + error.message + "</p>");
    }
}

// ==========================================================================
// 5. GRÁFICO 2: MAPA DE CALOR DE PRECIOS POR HOTEL Y MES
// ==========================================================================

/**
 * Crea un mapa de calor para visualizar precios por hotel y mes
 * @param {Array} data - Datos a visualizar
 */
function createPriceHeatmap(data) {
    try {
        // Limpiar el contenedor
        const chartContainer = d3.select("#chart2").html("");
        
        // Crear SVG
        const svg = chartContainer.append("svg")
            .attr("width", "100%")
            .attr("height", "100%")
            .attr("viewBox", `0 0 900 400`)
            .attr("preserveAspectRatio", "xMidYMid meet");
            
        // Configurar los márgenes
        const margin = {top: 60, right: 40, bottom: 60, left: 110};
        const width = 900 - margin.left - margin.right;
        const height = 400 - margin.top - margin.bottom;
        const g = svg.append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);
        
        // Obtener tooltip
        const tooltip = getTooltip();
        
        // Procesar datos para el mapa de precios
        const hotelTypes = [...new Set(data.map(d => d.hotel))].filter(Boolean);
        
        // Calcular precios promedio por hotel y mes
        const priceData = [];
        hotelTypes.forEach(hotel => {
            monthOrder.forEach(month => {
                const monthData = data.filter(d => d.hotel === hotel && d.arrival_date_month === month);
                if (monthData.length > 0) {
                    const avgPrice = monthData.reduce((sum, d) => sum + (d.adr || 0), 0) / monthData.length;
                    const cancelRate = monthData.filter(d => d.is_canceled === 1).length / monthData.length;
                    const reservationCount = monthData.length;
                    
                    priceData.push({
                        hotel,
                        month,
                        avgPrice,
                        cancelRate,
                        reservationCount,
                        monthIndex: monthOrder.indexOf(month)
                    });
                }
            });
        });
        
        // Escalas
        const xScale = d3.scaleBand()
            .domain(monthOrder)
            .range([0, width])
            .padding(0.1);
            
        const yScale = d3.scaleBand()
            .domain(hotelTypes)
            .range([0, height])
            .padding(0.1);
            
        const radiusScale = d3.scaleLinear()
            .domain([0, d3.max(priceData, d => d.reservationCount) || 1])
            .range([5, 25]);
            
        const colorScale = d3.scaleLinear()
            .domain([
                d3.min(priceData, d => d.avgPrice) || 0, 
                d3.median(priceData, d => d.avgPrice) || 500, 
                d3.max(priceData, d => d.avgPrice) || 1000
            ])
            .range(["#3498db", "#f39c12", "#e74c3c"]);
            
        // Dibujar círculos para cada combinación hotel-mes
        g.selectAll("circle")
            .data(priceData)
            .join("circle")
            .attr("class", "price-circle")
            .attr("cx", d => xScale(d.month) + xScale.bandwidth() / 2)
            .attr("cy", d => yScale(d.hotel) + yScale.bandwidth() / 2)
            .attr("r", d => radiusScale(d.reservationCount))
            .attr("fill", d => colorScale(d.avgPrice))
            .attr("opacity", 0.8)
            .on("mouseover", function(event, d) {
                d3.select(this)
                    .attr("stroke", "#000")
                    .attr("stroke-width", 2);
                    
                tooltip.transition()
                    .duration(200)
                    .style("opacity", .9);
                    
                tooltip.html(`<strong>${d.hotel} - ${d.month}</strong><br>
                           Precio promedio: ${formatNumber(Math.round(d.avgPrice))}€<br>
                           Reservas: ${d.reservationCount}<br>
                           Tasa de cancelación: ${formatPercent(d.cancelRate)}`)
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 28) + "px");
            })
            .on("mouseout", function() {
                d3.select(this)
                    .attr("stroke", "white")
                    .attr("stroke-width", 1);
                    
                tooltip.transition()
                    .duration(500)
                    .style("opacity", 0);
            });
            
        // Añadir etiquetas de meses (eje X)
        g.append("g")
            .attr("transform", `translate(0,${height})`)
            .call(d3.axisBottom(xScale))
            .selectAll("text")
            .attr("y", 10)
            .attr("x", 0)
            .attr("dy", ".35em")
            .attr("transform", "rotate(45)")
            .attr("text-anchor", "start");
            
        // Añadir etiquetas de hoteles (eje Y)
        g.append("g")
            .call(d3.axisLeft(yScale));
            
        // Añadir título de ejes
        svg.append("text")
            .attr("transform", `translate(${width/2 + margin.left}, ${height + margin.top + 50})`)
            .attr("text-anchor", "middle")
            .attr("class", "axis-title")
            .text("Mes");
            
        svg.append("text")
            .attr("transform", "rotate(-90)")
            .attr("x", -(height/2 + margin.top))
            .attr("y", 30)
            .attr("text-anchor", "middle")
            .attr("class", "axis-title")
            .text("Tipo de Hotel");
            
        // Leyenda de tamaño
        const legendSize = svg.append("g")
            .attr("transform", `translate(${width + margin.left - 150}, ${margin.top - 40})`);
            
        const legendSizes = [
            Math.round(d3.min(priceData, d => d.reservationCount) || 1),
            Math.round(d3.median(priceData, d => d.reservationCount) || 5), 
            Math.round(d3.max(priceData, d => d.reservationCount) || 10)
        ];
                           
        legendSize.selectAll("circle")
            .data(legendSizes)
            .join("circle")
            .attr("cx", 0)
            .attr("cy", (d, i) => 7.5 * Math.pow(i, 2) + 17.5 * i - 15)
            .attr("r", d => radiusScale(d))
            .attr("fill", "none")
            .attr("stroke", "#555");
            
        legendSize.selectAll("text")
            .data(legendSizes)
            .join("text")
            .attr("x", 30)
            .attr("y", (d, i) => 7.5 * Math.pow(i, 2) + 17.5 * i - 15)
            .attr("dy", "0.35em")
            .attr("font-size", "10px")
            .text(d => `${d} reservas`);
            
        legendSize.append("text")
            .attr("x", 0)
            .attr("y", -35)
            .attr("font-size", "10px")
            .attr("font-weight", "bold")
            .text("Volumen");
            
        // Leyenda de color
        const legendColor = svg.append("g")
            .attr("transform", `translate(${margin.left}, ${margin.top - 40})`);
            
        const gradientId = "price-gradient";
        
        // Crear un gradiente para la leyenda de color
        const gradient = legendColor.append("defs")
            .append("linearGradient")
            .attr("id", gradientId)
            .attr("x1", "0%")
            .attr("y1", "0%")
            .attr("x2", "100%")
            .attr("y2", "0%");
            
        gradient.append("stop")
            .attr("offset", "0%")
            .attr("stop-color", colorScale.range()[0]);
            
        gradient.append("stop")
            .attr("offset", "50%")
            .attr("stop-color", colorScale.range()[1]);
            
        gradient.append("stop")
            .attr("offset", "100%")
            .attr("stop-color", colorScale.range()[2]);
            
        // Crear la barra de leyenda
        legendColor.append("rect")
            .attr("width", 200)
            .attr("height", 10)
            .style("fill", `url(#${gradientId})`);
            
        // Añadir etiquetas de leyenda
        const legendLabels = [
            Math.round(d3.min(priceData, d => d.avgPrice) || 0),
            Math.round(d3.median(priceData, d => d.avgPrice) || 500),
            Math.round(d3.max(priceData, d => d.avgPrice) || 1000)
        ];
        
        legendColor.selectAll(".legend-label")
            .data(legendLabels)
            .join("text")
            .attr("class", "legend-label")
            .attr("x", (d, i) => i * 100)
            .attr("y", 25)
            .attr("text-anchor", (d, i) => i === 0 ? "start" : i === 1 ? "middle" : "end")
            .attr("font-size", "10px")
            .text(d => `${formatNumber(d)}€`);
            
        legendColor.append("text")
            .attr("x", 0)
            .attr("y", -5)
            .attr("font-size", "10px")
            .attr("font-weight", "bold")
            .text("Precio promedio (ADR)");
    } catch (error) {
        console.error("Error al crear mapa de calor:", error);
        d3.select("#chart2").html("<p class='error-message'>Error al crear la visualización: " + error.message + "</p>");
    }
}

// ==========================================================================
// 6. GRÁFICO 3: GRÁFICO DE BURBUJAS (SOLICITUDES ESPECIALES VS DURACIÓN)
// ==========================================================================

/**
 * Crea un gráfico de burbujas para visualizar la relación entre 
 * solicitudes especiales y duración de estancia
 * @param {Array} data - Datos a visualizar
 */
function createBubbleChart(data) {
    try {
        // Limpiar el contenedor
        const chartContainer = d3.select("#chart3").html("");
        
        // Crear SVG
        const svg = chartContainer.append("svg")
            .attr("width", "100%")
            .attr("height", "100%")
            .attr("viewBox", `0 0 900 400`)
            .attr("preserveAspectRatio", "xMidYMid meet");
            
        // Configurar márgenes
        const margin = {top: 60, right: 40, bottom: 100, left: 80};
        const width = 900 - margin.left - margin.right;
        const height = 400 - margin.top - margin.bottom;
        const g = svg.append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);
            
        // Obtener tooltip
        const tooltip = getTooltip();
        
        // Agregar datos por características clave
        const bubbleData = [];
        
        // Agrupar por tipo de cliente, total de solicitudes especiales y duración de estancia
        const customerTypes = [...new Set(data.map(d => d.customer_type))].filter(Boolean);
        const hotelTypes = [...new Set(data.map(d => d.hotel))].filter(Boolean);
        
        // Asegurar que tenemos los tipos de cliente y hotel válidos
        if (customerTypes.length === 0 || hotelTypes.length === 0) {
            throw new Error("No se encontraron tipos de cliente o hotel válidos");
        }
        
        customerTypes.forEach(customerType => {
            const customerData = data.filter(d => d.customer_type === customerType);
            
            // Las posibles solicitudes especiales van de 0 a 5
            for (let requests = 0; requests <= 5; requests++) {
                // Categorías de duración de estancia
                const stayCategories = ["1-2 noches", "3-5 noches", "6-10 noches", "Más de 10 noches"];
                
                stayCategories.forEach(stayCategory => {
                    hotelTypes.forEach(hotel => {
                        // Filtrar por todos los criterios
                        const filteredData = customerData.filter(d => 
                            d.total_of_special_requests === requests && 
                            d.stay_category === stayCategory &&
                            d.hotel === hotel
                        );
                        
                        const count = filteredData.length;
                        
                        // Solo incluir si hay reservas
                        if (count > 0) {
                            const avgAdr = filteredData.reduce((sum, d) => sum + (d.adr || 0), 0) / count;
                            
                            bubbleData.push({
                                customerType,
                                hotel,
                                requests,
                                stayCategory,
                                count,
                                avgAdr
                            });
                        }
                    });
                });
            }
        });
        
        // Si no hay datos, mostrar mensaje
        if (bubbleData.length === 0) {
            chartContainer.html("<p class='error-message'>No hay datos disponibles para esta visualización con los filtros actuales</p>");
            return;
        }
        
        // Mapeo de categorías de estancia a valores numéricos para el eje X
        const stayToNumber = {
            "1-2 noches": 1,
            "3-5 noches": 3.5,
            "6-10 noches": 8,
            "Más de 10 noches": 12
        };
        
        // Convertir categorías a números para el eje X
        bubbleData.forEach(d => {
            d.stayValue = stayToNumber[d.stayCategory] || 0;
        });
        
        // Escalas
        const xScale = d3.scaleLinear()
            .domain([0, 13])
            .range([0, width]);
            
        const yScale = d3.scaleLinear()
            .domain([0, 5])
            .range([height, 0]);
            
        const sizeScale = d3.scaleSqrt()
            .domain([0, d3.max(bubbleData, d => d.count) || 1])
            .range([4, 25]);
            
        // Crear escalas de color
        const colorByCustomer = d3.scaleOrdinal()
            .domain(customerTypes)
            .range(Object.values(colors.customerTypes).slice(0, customerTypes.length));
            
        const colorByHotel = d3.scaleOrdinal()
            .domain(hotelTypes)
            .range(Object.values(colors.hotels).slice(0, hotelTypes.length));
            
        // Establecer color predeterminado
        let colorScale = colorByCustomer;
        
        // Añadir ejes
        g.append("g")
            .attr("transform", `translate(0,${height})`)
            .call(d3.axisBottom(xScale)
                .tickValues([1, 3.5, 8, 12])
                .tickFormat((d, i) => {
                    const labels = ["1-2 noches", "3-5 noches", "6-10 noches", "Más de 10 noches"];
                    return labels[i] || "";
                }))
            .selectAll("text")
            .attr("y", 35)
            .attr("x", 0)
            .attr("dy", ".35em")
            .attr("transform", "rotate(0)")
            .attr("text-anchor", "start");
            
        g.append("g")
            .call(d3.axisLeft(yScale)
                .tickValues([0, 1, 2, 3, 4, 5]));
            
        // Añadir título de ejes
        svg.append("text")
            .attr("transform", `translate(${width/2 + margin.left}, ${height + margin.top + 70})`)
            .attr("text-anchor", "middle")
            .attr("class", "axis-title")
            .text("Duración de la Estancia");
            
        svg.append("text")
            .attr("transform", "rotate(-90)")
            .attr("x", -(height/2 + margin.top))
            .attr("y", 30)
            .attr("text-anchor", "middle")
            .attr("class", "axis-title")
            .text("Número de Solicitudes Especiales");
        
        // Crear burbujas
        const bubbles = g.selectAll(".node")
            .data(bubbleData)
            .join("circle")
            .attr("class", "node")
            .attr("cx", d => xScale(d.stayValue))
            .attr("cy", d => yScale(d.requests))
            .attr("r", d => sizeScale(d.count))
            .attr("fill", d => colorScale(d.customerType))
            .attr("opacity", 0.7)
            .attr("stroke", "#fff")
            .attr("stroke-width", 1)
            .on("mouseover", function(event, d) {
                d3.select(this)
                    .attr("stroke", "#000")
                    .attr("stroke-width", 2)
                    .attr("opacity", 1);
                    
                tooltip.transition()
                    .duration(200)
                    .style("opacity", .9);
                    
                tooltip.html(`<strong>${d.customerType} - ${d.hotel}</strong><br>
                           Solicitudes especiales: ${d.requests}<br>
                           Duración: ${d.stayCategory}<br>
                           Cantidad: ${d.count} reservas<br>
                           Precio medio: ${formatNumber(Math.round(d.avgAdr))}€`)
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 28) + "px");
            })
            .on("mouseout", function() {
                d3.select(this)
                    .attr("stroke", "#fff")
                    .attr("stroke-width", 1)
                    .attr("opacity", 0.7);
                    
                tooltip.transition()
                    .duration(500)
                    .style("opacity", 0);
            });
            
        // Leyenda dinámica - colocada más arriba y separada del gráfico
        const legend = svg.append("g")
            .attr("class", "legend")
            .attr("transform", `translate(${margin.left}, ${margin.top - 40})`);
            
        function updateLegend(colorScale, title) {
            // Limpiar leyenda anterior
            legend.selectAll("*").remove();
            
            // Obtener los dominios y rangos de la escala de color
            const domains = colorScale.domain();
            
            // Título de la leyenda
            legend.append("text")
                .attr("x", 0)
                .attr("y", -10)
                .attr("font-size", "10px")
                .attr("font-weight", "bold")
                .text(title);
                
            // Elementos de leyenda
            domains.forEach((d, i) => {
                const legendItem = legend.append("g")
                    .attr("transform", `translate(${i * 150}, 0)`);
                    
                legendItem.append("circle")
                    .attr("r", 6)
                    .attr("fill", colorScale(d))
                    .attr("opacity", 0.7);
                    
                legendItem.append("text")
                    .attr("x", 10)
                    .attr("y", 0)
                    .attr("dy", "0.35em")
                    .attr("font-size", "10px")
                    .text(d);
            });
        }
        
        // Mostrar leyenda inicialmente por tipo de cliente
        updateLegend(colorByCustomer, "Tipo de Cliente");
        
        // Configurar botones para cambiar coloración
        const customerButton = document.getElementById("color-by-customer");
        const hotelButton = document.getElementById("color-by-hotel");
        
        if (customerButton) {
            customerButton.addEventListener("click", function() {
                colorScale = colorByCustomer;
                bubbles.transition()
                    .duration(500)
                    .attr("fill", d => colorScale(d.customerType));
                updateLegend(colorByCustomer, "Tipo de Cliente");
            });
        }
        
        if (hotelButton) {
            hotelButton.addEventListener("click", function() {
                colorScale = colorByHotel;
                bubbles.transition()
                    .duration(500)
                    .attr("fill", d => colorScale(d.hotel));
                updateLegend(colorByHotel, "Tipo de Hotel");
            });
        }
    } catch (error) {
        console.error("Error al crear gráfico de burbujas:", error);
        d3.select("#chart3").html("<p class='error-message'>Error al crear la visualización: " + error.message + "</p>");
    }
}

// ==========================================================================
// 7. CONFIGURACIÓN DE FILTROS E INTERACTIVIDAD
// ==========================================================================

/**
 * Configura los filtros y la interactividad del dashboard
 */
function setupFilters() {
    try {
        // Filtros para gráfico 1: Sankey
        const hotelFilter1 = document.getElementById('hotel-filter-1');
        const yearFilter1 = document.getElementById('year-filter-1');
        
        if (hotelFilter1) {
            hotelFilter1.addEventListener('change', function() {
                applyFilters();
            });
        }
        
        if (yearFilter1) {
            yearFilter1.addEventListener('change', function() {
                applyFilters();
            });
        }
        
        // Filtros para gráfico 2: Mapa de calor de precios
        const yearFilter2 = document.getElementById('year-filter-2');
        
        if (yearFilter2) {
            yearFilter2.addEventListener('change', function() {
                applyFilters();
            });
        }
        
        // Filtros para gráfico 3: Gráfico de burbujas
        const hotelFilter3 = document.getElementById('hotel-filter-3');
        const customerFilter3 = document.getElementById('customer-filter-3');
        
        if (hotelFilter3) {
            hotelFilter3.addEventListener('change', function() {
                applyFilters();
            });
        }
        
        if (customerFilter3) {
            customerFilter3.addEventListener('change', function() {
                applyFilters();
            });
        }
    } catch (error) {
        console.error("Error al configurar filtros:", error);
    }
}

/**
 * Aplica los filtros seleccionados a las visualizaciones
 */
function applyFilters() {
    try {
        // Obtener valores de filtros para el gráfico 1
        const hotelFilter1 = document.getElementById('hotel-filter-1');
        const yearFilter1 = document.getElementById('year-filter-1');
        
        let filteredData1 = [...fullData];
        
        if (hotelFilter1 && hotelFilter1.value !== 'todos') {
            filteredData1 = filteredData1.filter(d => d.hotel === hotelFilter1.value);
        }
        
        if (yearFilter1 && yearFilter1.value !== 'todos') {
            filteredData1 = filteredData1.filter(d => d.arrival_date_year === +yearFilter1.value);
        }
        
        // Actualizar gráfico 1
        createSankeyChart(filteredData1);
        
        // Obtener valores de filtros para el gráfico 2
        const yearFilter2 = document.getElementById('year-filter-2');
        
        let filteredData2 = [...fullData];
        
        if (yearFilter2 && yearFilter2.value !== 'todos') {
            filteredData2 = filteredData2.filter(d => d.arrival_date_year === +yearFilter2.value);
        }
        
        // Actualizar gráfico 2
        createPriceHeatmap(filteredData2);
        
        // Obtener valores de filtros para el gráfico 3
        const hotelFilter3 = document.getElementById('hotel-filter-3');
        const customerFilter3 = document.getElementById('customer-filter-3');
        
        let filteredData3 = [...fullData];
        
        if (hotelFilter3 && hotelFilter3.value !== 'todos') {
            filteredData3 = filteredData3.filter(d => d.hotel === hotelFilter3.value);
        }
        
        if (customerFilter3 && customerFilter3.value !== 'todos') {
            filteredData3 = filteredData3.filter(d => d.customer_type === customerFilter3.value);
        }
        
        // Actualizar gráfico 3
        createBubbleChart(filteredData3);
        
        // Actualizar indicadores globales
        updateGlobalStats();
    } catch (error) {
        console.error("Error al aplicar filtros:", error);
    }
}

/**
 * Actualiza los estadísticos globales basados en los filtros activos
 */
function updateGlobalStats() {
    try {
        // Obtener todos los filtros activos
        const hotelFilter1 = document.getElementById('hotel-filter-1');
        const yearFilter1 = document.getElementById('year-filter-1');
        
        // Aplicar el filtro más restrictivo para los indicadores globales
        let filteredData = [...fullData];
        
        if (hotelFilter1 && hotelFilter1.value !== 'todos') {
            filteredData = filteredData.filter(d => d.hotel === hotelFilter1.value);
        }
        
        if (yearFilter1 && yearFilter1.value !== 'todos') {
            filteredData = filteredData.filter(d => d.arrival_date_year === +yearFilter1.value);
        }
        
        // Actualizar indicadores
        updateIndicators(filteredData);
    } catch (error) {
        console.error("Error al actualizar estadísticas globales:", error);
    }
}

// ==========================================================================
// 8. INICIALIZACIÓN DEL DASHBOARD
// ==========================================================================

/**
 * Punto de entrada principal del script
 * Inicia la carga de datos y configuración del dashboard
 */
(function init() {
    console.log("Inicializando Dashboard de Tendencias en Reservas Hoteleras...");
    
    // Mostrar mensajes de carga
    document.querySelectorAll('.indicator-value').forEach(el => {
        if (el) el.textContent = "...";
    });
    
    // Cargar datos
    loadData();
    
    // Configurar eventos de ventana
    window.addEventListener('resize', function() {
        console.log("Redimensionando el dashboard...");
    });

    // Prevenir errores en eventos del mouse
    document.addEventListener('dblclick', function(event) {
        event.preventDefault();
        event.stopPropagation();
        return false;
    }, true);

    // Manejar cualquier error relacionado con eventos del mouse
    document.addEventListener('mousedown', handleMouseError, true);
    document.addEventListener('mouseup', handleMouseError, true);
    document.addEventListener('mousemove', handleMouseError, true);
    document.addEventListener('click', handleMouseError, true);
})();

/**
 * Manejador general para capturar errores en eventos del mouse
 * @param {Event} event - Evento del mouse
 */
function handleMouseError(event) {
    try {
        // Validar el evento y su objetivo
        if (event && event.target && typeof event.target.className === 'string') {
            // console.log("Evento de mouse:", event.type, "en", event.target.className);
        }
    } catch (error) {
        // Evitar que el error se propague
        console.warn("Evento de mouse capturado:", error.message);
        if (event) {
            event.stopPropagation();
        }
        return false;
    }
}